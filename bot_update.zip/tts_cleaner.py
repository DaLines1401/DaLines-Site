import re
import discord

URL_PATTERN = re.compile(r"https?://\S+")
DISCORD_EMOJI_PATTERN = re.compile(r"<a?:([a-zA-Z0-9_]+):\d+>")
USER_MENTION_PATTERN = re.compile(r"<@!?(\d+)>")
ROLE_MENTION_PATTERN = re.compile(r"<@&(\d+)>")
CHANNEL_MENTION_PATTERN = re.compile(r"<#(\d+)>")
CODE_BLOCK_PATTERN = re.compile(r"```[\s\S]*?```")
SPOILER_PATTERN = re.compile(r"\|\|.*?\|\|")
INLINE_CODE_PATTERN = re.compile(r"`([^`]+)`")
MARKDOWN_PATTERN = re.compile(r"[*_~]")

def clean_discord_message(message: discord.Message, max_length: int = 250) -> str:
    """
    แปลงและกรองข้อความจาก Discord ให้พร้อมสำหรับส่งไปอ่าน TTS
    """
    raw_content = message.content or ""
    guild = message.guild

    # ถ้าไม่มีเนื้อหา แต่มีไฟล์แนบหรือสติกเกอร์
    if not raw_content.strip():
        if message.attachments:
            # เช็คว่ามีรูปภาพหรือไม่
            is_image = any(att.content_type and "image" in att.content_type for att in message.attachments)
            return "ส่งรูปภาพ" if is_image else "ส่งไฟล์แนบ"
        if message.stickers:
            return "ส่งสติกเกอร์"
        return ""

    # แทนที่ Code Block
    text = CODE_BLOCK_PATTERN.sub("ส่งโค้ด", raw_content)

    # แทนที่ Spoiler
    text = SPOILER_PATTERN.sub("ข้อความสปอยล์", text)

    # แปลง URL
    text = URL_PATTERN.sub("ส่งลิงก์", text)

    # แปลง Mention ผู้ใช้ เป็นชื่อผู้ใช้
    if guild:
        def replace_user(match):
            user_id = int(match.group(1))
            member = guild.get_member(user_id)
            if member:
                return f"@{member.display_name}"
            return "@ผู้ใช้"
        text = USER_MENTION_PATTERN.sub(replace_user, text)

        def replace_role(match):
            role_id = int(match.group(1))
            role = guild.get_role(role_id)
            if role:
                return f"@{role.name}"
            return "@ยศ"
        text = ROLE_MENTION_PATTERN.sub(replace_role, text)

        def replace_channel(match):
            ch_id = int(match.group(1))
            ch = guild.get_channel(ch_id)
            if ch:
                return f"#{ch.name}"
            return "#ห้อง"
        text = CHANNEL_MENTION_PATTERN.sub(replace_channel, text)
    else:
        text = USER_MENTION_PATTERN.sub("@ผู้ใช้", text)
        text = ROLE_MENTION_PATTERN.sub("@ยศ", text)
        text = CHANNEL_MENTION_PATTERN.sub("#ห้อง", text)

    # แปลง Discord Custom Emoji ให้เหลือแค่ชื่อ หรือตัดออก
    text = DISCORD_EMOJI_PATTERN.sub(r":\1:", text)

    # จัดการ Inline code และ Markdown ทั่วไป
    text = INLINE_CODE_PATTERN.sub(r"\1", text)
    text = MARKDOWN_PATTERN.sub("", text)

    # ตัดช่องว่างซ้ำซ้อน และขึ้นบรรทัดใหม่
    text = re.sub(r"\s+", " ", text).strip()

    # ตัดความยาวหากเกินกำหนด
    if len(text) > max_length:
        text = text[:max_length] + "... ข้อความยาวเกินไป"

    return text
