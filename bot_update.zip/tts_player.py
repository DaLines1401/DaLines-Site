import asyncio
import logging
import re
import time
import uuid
from dataclasses import dataclass
from pathlib import Path
from typing import Optional, Dict, Set, List, Tuple

import discord
import edge_tts
from gtts import gTTS

import config

logger = logging.getLogger(__name__)

THAI_CHAR_PATTERN = re.compile(r"[\u0e00-\u0e7f]")
ENGLISH_CHAR_PATTERN = re.compile(r"[a-zA-Z]")
TOKEN_SPLIT_PATTERN = re.compile(
    r"([\u0e00-\u0e7f]+|[a-zA-Z]+(?:'[a-zA-Z]+)?|[0-9]+|\s+|[^\u0e00-\u0e7fa-zA-Z0-9\s]+)"
)


def get_matching_voice_pair(current_voice: str) -> Tuple[str, str]:
    """
    จับคู่เพศเสียงอัตโนมัติ (Gender-Matched Pairing):
    - หญิงไทย (เปรมวดี) <-> Ava (หญิงอังกฤษ US)
    - ชายไทย (นิวัฒน์) <-> Guy (ชายอังกฤษ US)
    - Google แปลภาษาไทย <-> Google แปลภาษาอังกฤษ
    """
    if "Niwat" in current_voice or "Guy" in current_voice:
        return ("th-TH-NiwatNeural", "en-US-GuyNeural")
    elif current_voice.startswith("google-"):
        return ("google-th", "google-en")
    else:
        return ("th-TH-PremwadeeNeural", "en-US-AvaNeural")


def segment_bilingual_text(text: str) -> List[Tuple[str, str]]:
    """
    แยกข้อความสองภาษา (ไทยและอังกฤษ) ในประโยคเดียวอย่างเป็นธรรมชาติ
    - ท่อนภาษาไทย -> lang 'th'
    - ท่อนภาษาอังกฤษ -> lang 'en'
    - ตัวเลขและเครื่องหมายวรรคตอนผูกติดกับภาษาข้างเคียง (Context-Aware)
    - รวบคำภาษาอังกฤษที่อยู่ติดกันเป็นก้อนเดียวเพื่อความลื่นไหล
    """
    if not text:
        return []

    raw_tokens = TOKEN_SPLIT_PATTERN.findall(text)
    if not raw_tokens:
        return [("th", text)]

    tokens = []
    for t in raw_tokens:
        if not t:
            continue
        if THAI_CHAR_PATTERN.search(t):
            tokens.append((t, "th"))
        elif ENGLISH_CHAR_PATTERN.search(t):
            tokens.append((t, "en"))
        elif t.isdigit():
            tokens.append((t, "num"))
        else:
            tokens.append((t, "other"))

    # ค้นหาภาษาหลักตั้งต้น
    current_lang = "th"
    for t, t_type in tokens:
        if t_type in ("th", "en"):
            current_lang = t_type
            break

    resolved = []
    for i, (t, t_type) in enumerate(tokens):
        if t_type in ("th", "en"):
            current_lang = t_type
            resolved.append((t, t_type))
        elif t_type == "num":
            # Context-Aware: ดูข้างหน้าว่ามีคำภาษาอังกฤษอยู่ติดกันหรือไม่
            next_lang = None
            for j in range(i + 1, len(tokens)):
                if tokens[j][1] in ("th", "en"):
                    next_lang = tokens[j][1]
                    break
            lang = "en" if (next_lang == "en" or current_lang == "en") else "th"
            resolved.append((t, lang))
        else:
            resolved.append((t, current_lang))

    # รวบกลุ่มคำภาษาเดียวกันที่อยู่ติดกัน
    chunks = []
    for t, lang in resolved:
        if not chunks:
            chunks.append({"lang": lang, "text": t})
        else:
            last = chunks[-1]
            if last["lang"] == lang:
                last["text"] += t
            else:
                chunks.append({"lang": lang, "text": t})

    # กรองท่อนที่เป็นช่องว่างล้วน
    final_chunks = []
    for c in chunks:
        trimmed = c["text"].strip()
        if trimmed:
            final_chunks.append((c["lang"], c["text"]))

    # หากมีภาษาเดียวตลอดทั้งประโยค ให้คืนเป็น 1 ก้อน
    distinct_langs = {c[0] for c in final_chunks}
    if len(distinct_langs) <= 1 and final_chunks:
        return [(final_chunks[0][0], text)]

    return final_chunks


def get_voice_for_text(text: str, current_voice: str, auto_language: bool = True) -> str:
    """
    ตรวจจับภาษาเดี่ยว (สำหรับ fallback หรือข้อความภาษาเดียว)
    """
    if not auto_language:
        return current_voice

    if THAI_CHAR_PATTERN.search(text):
        return current_voice

    if ENGLISH_CHAR_PATTERN.search(text):
        th_v, en_v = get_matching_voice_pair(current_voice)
        return en_v

    return current_voice


class TTSMemoryCache:
    """
    ⚡ ระบบ In-Memory Pre-Cache สำหรับคำสตรีมเมอร์ยอดนิยมและข้อความสั้น
    - เก็บ Audio File ใน RAM Disk (/dev/shm) หรือ RAM Buffer
    - ตอบสนองเสียงทันที 0ms (Zero Latency) ไม่ต้องรอเน็ต Cloud TTS
    """
    def __init__(self, temp_dir: Path):
        self.temp_dir = temp_dir
        self._cache_bytes: Dict[tuple, bytes] = {}
        self._cache_files: Dict[tuple, Path] = {}
        self.hits: int = 0
        self.misses: int = 0
        self.custom_phrases: Set[str] = set()

    @staticmethod
    def normalize_key(text: str) -> str:
        return " ".join(text.strip().lower().split())

    def _get_key(self, text: str, voice: str, rate: str) -> tuple:
        return (self.normalize_key(text), voice, rate)

    def count(self) -> int:
        return len(self._cache_files)

    def get_phrases(self) -> List[str]:
        phrases = set()
        for k in self._cache_files.keys():
            phrases.add(k[0])
        return sorted(list(phrases))

    def get_cached_file(self, text: str, voice: str, rate: str) -> Optional[Path]:
        key = self._get_key(text, voice, rate)
        file_path = self._cache_files.get(key)
        if file_path and file_path.exists():
            self.hits += 1
            return file_path

        # กรณีมี bytes ในหน่วยความจำแต่ไฟล์ยังไม่ได้เขียนลง RAM disk
        if key in self._cache_bytes:
            self.hits += 1
            safe_name = f"cache_{abs(hash(key)) % 100000000:08d}.mp3"
            path = self.temp_dir / safe_name
            try:
                path.write_bytes(self._cache_bytes[key])
                self._cache_files[key] = path
                return path
            except Exception:
                pass
        self.misses += 1
        return None

    def put_cache(self, text: str, voice: str, rate: str, audio_bytes: bytes) -> Optional[Path]:
        key = self._get_key(text, voice, rate)
        # ป้องกัน RAM ล้น: จำกัดหน่วยความจำแคชไว้ 300 คำ
        if len(self._cache_bytes) > 300:
            first_key = next(iter(self._cache_bytes))
            del self._cache_bytes[first_key]
            old_file = self._cache_files.pop(first_key, None)
            if old_file and old_file.exists():
                try:
                    old_file.unlink()
                except Exception:
                    pass

        self._cache_bytes[key] = audio_bytes
        safe_name = f"cache_{abs(hash(key)) % 100000000:08d}.mp3"
        path = self.temp_dir / safe_name
        try:
            path.write_bytes(audio_bytes)
            self._cache_files[key] = path
            return path
        except Exception:
            return None

    async def warm_phrase(self, phrase: str, voice: str, rate: str):
        key = self._get_key(phrase, voice, rate)
        if key in self._cache_files and self._cache_files[key].exists():
            return

        safe_name = f"cache_{abs(hash(key)) % 100000000:08d}.mp3"
        dest_path = self.temp_dir / safe_name
        try:
            if voice.startswith("google-"):
                lang = voice.split("-")[1]
                def _gen():
                    tts = gTTS(text=phrase, lang=lang)
                    tts.save(str(dest_path))
                await asyncio.to_thread(_gen)
            else:
                communicate = edge_tts.Communicate(text=phrase, voice=voice, rate=rate)
                await communicate.save(str(dest_path))

            data = dest_path.read_bytes()
            self._cache_bytes[key] = data
            self._cache_files[key] = dest_path
        except Exception as e:
            logger.warning(f"[Pre-Cache] ไม่สามารถสังเคราะห์คำว่า '{phrase}' ({voice}): {e}")


@dataclass
class TTSItem:
    text: str
    author_name: str
    guild_id: int
    source: str = "Discord"
    voice: Optional[str] = None
    rate: Optional[str] = None


class GuildTTSState:
    def __init__(self, guild_id: int, bot: discord.Client, manager: 'TTSManager'):
        self.guild_id = guild_id
        self.bot = bot
        self.manager = manager
        self.queue: asyncio.Queue[TTSItem] = asyncio.Queue()
        self.bound_channel_id: Optional[int] = None
        self.voice: str = config.DEFAULT_VOICE
        self.rate: str = config.DEFAULT_RATE
        self.read_name: bool = False
        self.worker_task: Optional[asyncio.Task] = None
        self.current_audio_file: Optional[Path] = None
        self.current_playing_text: Optional[str] = None
        self.recent_logs: List[Dict[str, str]] = []
        self.twitch_listener = None
        self.twitch_channels: Set[str] = set()
        self.twitch_announce_channel: bool = True
        self.twitch_read_name: bool = True
        self.strip_emotes: bool = True
        self.auto_language: bool = True
        self.user_cooldown_seconds: float = 3.0
        self.blacklist: Set[str] = set()
        self.user_last_seen: Dict[str, float] = {}

    @property
    def is_playing(self) -> bool:
        guild = self.bot.get_guild(self.guild_id)
        if guild and guild.voice_client:
            return bool(guild.voice_client.is_playing())
        return bool(self.current_playing_text)

    async def stop_twitch(self):
        if self.twitch_listener:
            try:
                await self.twitch_listener.stop()
            except Exception as e:
                logger.error(f"[Guild {self.guild_id}] เกิดข้อผิดพลาดในการหยุด Twitch: {e}")
            self.twitch_listener = None
        self.twitch_channels.clear()

    async def add_twitch_channel(self, channel: str):
        clean_ch = channel.lower().strip().lstrip("#")
        if not clean_ch:
            return
        self.twitch_channels.add(clean_ch)
        if self.twitch_listener:
            await self.twitch_listener.add_channel(clean_ch)

    async def remove_twitch_channel(self, channel: str):
        clean_ch = channel.lower().strip().lstrip("#")
        self.twitch_channels.discard(clean_ch)
        if self.twitch_listener:
            await self.twitch_listener.remove_channel(clean_ch)
        if len(self.twitch_channels) == 0:
            await self.stop_twitch()

    def start_worker(self):
        if self.worker_task is None or self.worker_task.done():
            self.worker_task = asyncio.create_task(self._worker_loop())

    def stop_worker(self):
        if self.worker_task and not self.worker_task.done():
            self.worker_task.cancel()
            self.worker_task = None

    def clear_queue(self):
        while not self.queue.empty():
            try:
                self.queue.get_nowait()
                self.queue.task_done()
            except (asyncio.QueueEmpty, ValueError):
                break

    async def _worker_loop(self):
        while True:
            try:
                item = await self.queue.get()
            except asyncio.CancelledError:
                break

            guild = self.bot.get_guild(self.guild_id)
            if not guild:
                self.queue.task_done()
                continue

            voice_client: Optional[discord.VoiceClient] = guild.voice_client
            if not voice_client or not voice_client.is_connected():
                self.queue.task_done()
                continue

            # Anti-flood: หากคิวสะสมเกิน 15 ข้อความ ให้ตัดข้อความเก่าออกเพื่อไล่ให้ทันแชทสด
            if self.queue.qsize() > 15:
                dropped = 0
                while self.queue.qsize() > 8:
                    try:
                        self.queue.get_nowait()
                        self.queue.task_done()
                        dropped += 1
                    except Exception:
                        break
                if dropped:
                    logger.warning(f"[Guild {self.guild_id}] ข้ามข้อความแชทเก่า {dropped} ข้อความ เพื่อเร่งให้ทันสตรีมสด")

            # ประกอบข้อความที่จะอ่าน
            spoken_text = item.text
            if self.read_name and item.author_name:
                spoken_text = f"{item.author_name} พูดว่า {spoken_text}"

            # ปรับสปีดอัตโนมัติเมื่อมีคิวรออ่านเยอะ (Dynamic Speed Boost)
            q_size = self.queue.qsize()
            effective_rate = item.rate or self.rate
            if q_size >= 8:
                effective_rate = "+40%"
            elif q_size >= 4:
                effective_rate = "+25%"

            # แยกท่อนคำสองภาษา (Bilingual Code-Switching)
            base_voice = item.voice or self.voice
            th_voice, en_voice = get_matching_voice_pair(base_voice)

            if self.auto_language:
                chunks = segment_bilingual_text(spoken_text)
            else:
                chunks = [("th" if THAI_CHAR_PATTERN.search(spoken_text) else "en", spoken_text)]

            audio_path: Optional[Path] = None
            is_from_cache = False
            created_parts: List[Path] = []
            concat_list_file: Optional[Path] = None

            try:
                # ----------------------------------------------------
                # กรณีที่ 1: ประโยคเป็นภาษาเดียวล้วน (Single Language)
                # ----------------------------------------------------
                if len(chunks) <= 1:
                    lang = chunks[0][0] if chunks else "th"
                    selected_voice = en_voice if lang == "en" else th_voice

                    cached_file = self.manager.cache.get_cached_file(spoken_text, selected_voice, effective_rate)
                    if cached_file and cached_file.exists():
                        audio_path = cached_file
                        is_from_cache = True
                        logger.info(f"[Guild {self.guild_id}] ⚡ Pre-Cache Hit (0ms): '{spoken_text}'")
                    else:
                        audio_id = uuid.uuid4().hex[:8]
                        audio_path = config.TEMP_AUDIO_DIR / f"tts_{self.guild_id}_{audio_id}.mp3"
                        self.current_audio_file = audio_path

                        if selected_voice.startswith("google-"):
                            lang_code = selected_voice.split("-")[1]
                            def generate_gtts():
                                tts = gTTS(text=spoken_text, lang=lang_code)
                                tts.save(str(audio_path))
                            await asyncio.to_thread(generate_gtts)
                        else:
                            communicate = edge_tts.Communicate(
                                text=spoken_text,
                                voice=selected_voice,
                                rate=effective_rate
                            )
                            await communicate.save(str(audio_path))

                        if len(spoken_text) <= 50 and audio_path.exists():
                            try:
                                data = audio_path.read_bytes()
                                self.manager.cache.put_cache(spoken_text, selected_voice, effective_rate, data)
                            except Exception:
                                pass

                # ----------------------------------------------------
                # กรณีที่ 2: ประโยคสองภาษาผสมไทย-อังกฤษ (Bilingual Multi-Voice)
                # ----------------------------------------------------
                else:
                    logger.info(f"[Guild {self.guild_id}] 🌐 ประมวลผลสองภาษา ({len(chunks)} ท่อน): {chunks}")

                    # ตรวจสอบว่าประโยคผสมนี้ถูกแคชไว้ใน RAM ล่วงหน้าแล้วหรือไม่
                    cached_file = self.manager.cache.get_cached_file(spoken_text, th_voice, effective_rate)
                    if cached_file and cached_file.exists():
                        audio_path = cached_file
                        is_from_cache = True
                        logger.info(f"[Guild {self.guild_id}] ⚡ Multi-Voice Cache Hit (0ms): '{spoken_text}'")
                    else:
                        async def _synth_part(txt: str, v: str) -> Path:
                            c = self.manager.cache.get_cached_file(txt, v, effective_rate)
                            if c and c.exists():
                                return c
                            part_id = uuid.uuid4().hex[:8]
                            part_p = config.TEMP_AUDIO_DIR / f"part_{self.guild_id}_{part_id}.mp3"
                            if v.startswith("google-"):
                                lang_code = v.split("-")[1]
                                def _g():
                                    t = gTTS(text=txt, lang=lang_code)
                                    t.save(str(part_p))
                                await asyncio.to_thread(_g)
                            else:
                                comm = edge_tts.Communicate(text=txt, voice=v, rate=effective_rate)
                                await comm.save(str(part_p))

                            if len(txt) <= 50 and part_p.exists():
                                try:
                                    self.manager.cache.put_cache(txt, v, effective_rate, part_p.read_bytes())
                                except Exception:
                                    pass
                            return part_p

                        # สังเคราะห์เสียงทุกท่อนแบบคู่ขนาน (Parallel Async Synthesis)
                        tasks = [_synth_part(txt, th_voice if lang == "th" else en_voice) for lang, txt in chunks]
                        part_paths = await asyncio.gather(*tasks)

                        valid_parts = [p for p in part_paths if p and p.exists()]
                        created_parts = [p for p in valid_parts if "cache_" not in p.name]

                        audio_id = uuid.uuid4().hex[:8]
                        audio_path = config.TEMP_AUDIO_DIR / f"tts_{self.guild_id}_{audio_id}.mp3"
                        self.current_audio_file = audio_path

                        if len(valid_parts) == 1:
                            audio_path = valid_parts[0]
                        elif len(valid_parts) > 1:
                            # รวมไฟล์เสียงใน RAM Disk (/dev/shm) ด้วย FFmpeg Concat Protocol (<3ms)
                            concat_list_file = config.TEMP_AUDIO_DIR / f"concat_{self.guild_id}_{audio_id}.txt"
                            concat_lines = "\n".join([f"file '{p.resolve().as_posix()}'" for p in valid_parts])
                            concat_list_file.write_text(concat_lines, encoding="utf-8")

                            cmd = [
                                config.FFMPEG_EXECUTABLE,
                                "-y",
                                "-f", "concat",
                                "-safe", "0",
                                "-i", str(concat_list_file),
                                "-c", "copy",
                                str(audio_path)
                            ]
                            proc = await asyncio.create_subprocess_exec(
                                *cmd,
                                stdout=asyncio.subprocess.DEVNULL,
                                stderr=asyncio.subprocess.DEVNULL
                            )
                            await proc.wait()

                            # Fallback หาก concat copy ไม่สำเร็จ ให้ใช้ filter_complex concat
                            if not audio_path.exists() or audio_path.stat().st_size == 0:
                                f_inputs = []
                                f_parts = []
                                for idx, p in enumerate(valid_parts):
                                    f_inputs.extend(["-i", str(p)])
                                    f_parts.append(f"[{idx}:a]")
                                f_str = f"{''.join(f_parts)}concat=n={len(valid_parts)}:v=0:a=1[out]"
                                cmd_fb = [
                                    config.FFMPEG_EXECUTABLE,
                                    "-y",
                                    *f_inputs,
                                    "-filter_complex", f_str,
                                    "-map", "[out]",
                                    "-c:a", "libmp3lame",
                                    str(audio_path)
                                ]
                                proc_fb = await asyncio.create_subprocess_exec(
                                    *cmd_fb,
                                    stdout=asyncio.subprocess.DEVNULL,
                                    stderr=asyncio.subprocess.DEVNULL
                                )
                                await proc_fb.wait()

                        # บันทึกเสียงประโยคสองภาษาที่รวมแล้วลง Memory Cache อัตโนมัติ (หาก <= 60 ตัวอักษร)
                        if len(spoken_text) <= 60 and audio_path and audio_path.exists():
                            try:
                                self.manager.cache.put_cache(spoken_text, th_voice, effective_rate, audio_path.read_bytes())
                            except Exception:
                                pass

                if not voice_client or not voice_client.is_connected():
                    continue

                # รอให้เสียงเดิมหยุดเล่นก่อน (ถ้ามี)
                while voice_client.is_playing() or voice_client.is_paused():
                    await asyncio.sleep(0.05)

                # บันทึกประวัติล่าสุดสำหรับ Dashboard
                self.current_playing_text = spoken_text
                log_source = item.source
                if is_from_cache:
                    log_source += " ⚡ [0ms Cache]"
                elif len(chunks) > 1:
                    log_source += " 🌐 [Bilingual TH+EN]"

                self.recent_logs.append({
                    "time": time.strftime("%H:%M:%S"),
                    "author": item.author_name or ("Web" if item.source == "Web" else "Chat"),
                    "text": spoken_text,
                    "source": log_source
                })
                if len(self.recent_logs) > 30:
                    self.recent_logs.pop(0)

                # ⚡ เล่นเสียงผ่าน Discord Voice ด้วย FFmpeg Low-Latency Optimization
                audio_source = discord.FFmpegPCMAudio(
                    str(audio_path),
                    executable=config.FFMPEG_EXECUTABLE,
                    before_options=config.FFMPEG_BEFORE_OPTIONS,
                    options=config.FFMPEG_OPTIONS
                )

                voice_client.play(audio_source)

                # รอจนกว่าเสียงจะเล่นจบ
                while voice_client.is_playing() or voice_client.is_paused():
                    await asyncio.sleep(0.05)

            except Exception as e:
                logger.error(f"[Guild {self.guild_id}] เกิดข้อผิดพลาดในการเล่น TTS: {e}")
            finally:
                self.current_playing_text = None
                # ลบ concat list file
                if concat_list_file and concat_list_file.exists():
                    try:
                        concat_list_file.unlink()
                    except Exception:
                        pass
                # ลบชิ้นส่วนเสียงย่อยชั่วคราว
                for cp in created_parts:
                    if cp != audio_path and cp.exists():
                        try:
                            cp.unlink()
                        except Exception:
                            pass
                # ลบไฟล์เสียงหลักที่เล่นจบแล้ว (เฉพาะไฟล์ที่ไม่ได้อยู่ใน Memory Cache)
                if not is_from_cache and audio_path and audio_path.exists() and "cache_" not in audio_path.name:
                    try:
                        audio_path.unlink()
                    except Exception:
                        pass
                self.current_audio_file = None
                self.queue.task_done()


class TTSManager:
    def __init__(self, bot: discord.Client):
        self.bot = bot
        self.states: Dict[int, GuildTTSState] = {}
        self.cache = TTSMemoryCache(config.TEMP_AUDIO_DIR)
        self.is_warming: bool = False

    def get_state(self, guild_id: int) -> GuildTTSState:
        if guild_id not in self.states:
            self.states[guild_id] = GuildTTSState(guild_id, self.bot, self)
        return self.states[guild_id]

    async def warm_default_cache(self, voices: Optional[List[str]] = None, rate: str = config.DEFAULT_RATE):
        """วอร์มเสียงคำสตรีมยอดฮิตลงใน RAM ล่วงหน้า เพื่อให้ตอบสนอง 0ms ทันทีที่สตาร์ตบอท"""
        if self.is_warming:
            return
        self.is_warming = True
        voices = voices or [config.DEFAULT_VOICE]
        logger.info(f"⚡ [Pre-Cache] เริ่มวอร์มเสียงคำสตรีมยอดนิยม {len(config.DEFAULT_PRECACHE_PHRASES)} คำ เข้าสู่ RAM ({config.TEMP_AUDIO_DIR})...")
        for phrase in config.DEFAULT_PRECACHE_PHRASES:
            for v in voices:
                try:
                    await self.cache.warm_phrase(phrase, v, rate)
                    await asyncio.sleep(0.02)
                except Exception as e:
                    logger.debug(f"[Pre-Cache] วอร์ม '{phrase}' ไม่สำเร็จ: {e}")
        self.is_warming = False
        logger.info(f"⚡ [Pre-Cache Complete] วอร์มเสียงเข้า RAM เรียบร้อยแล้ว {self.cache.count()} รายการ พร้อมความเร็ว 0ms!")

    async def enqueue(self, guild_id: int, text: str, author_name: str = "", source: str = "Discord", voice: Optional[str] = None, rate: Optional[str] = None):
        state = self.get_state(guild_id)
        state.start_worker()
        await state.queue.put(TTSItem(
            text=text,
            author_name=author_name,
            guild_id=guild_id,
            source=source,
            voice=voice,
            rate=rate
        ))

    def skip(self, guild_id: int) -> bool:
        guild = self.bot.get_guild(guild_id)
        if guild and guild.voice_client and guild.voice_client.is_playing():
            guild.voice_client.stop()
            return True
        return False

    def clear(self, guild_id: int):
        state = self.get_state(guild_id)
        state.clear_queue()
        guild = self.bot.get_guild(guild_id)
        if guild and guild.voice_client and guild.voice_client.is_playing():
            guild.voice_client.stop()
