import asyncio
import logging
import re
import time
import uuid
from dataclasses import dataclass
from pathlib import Path
from typing import Optional, Dict, Set, List

import discord
import edge_tts
from gtts import gTTS

import config

logger = logging.getLogger(__name__)

THAI_CHAR_PATTERN = re.compile(r"[\u0e00-\u0e7f]")
ENGLISH_WORD_PATTERN = re.compile(r"[a-zA-Z]{2,}")


def get_voice_for_text(text: str, current_voice: str, auto_language: bool = True) -> str:
    """
    ตรวจจับภาษาเพื่อเลือกเสียงสังเคราะห์ที่เหมาะสม:
    - หากมีภาษาไทย หรือปิด auto_language จะใช้เสียงปัจจุบัน
    - หากเป็นประโยคภาษาอังกฤษล้วน จะสลับเป็นเสียงเจ้าของภาษา US ชั่วคราว
    """
    if not auto_language:
        return current_voice

    # หากมีภาษาไทย ให้ใช้เสียงปัจจุบัน (เสียงไทย)
    if THAI_CHAR_PATTERN.search(text):
        return current_voice

    # หากไม่มีภาษาไทยเลย และมีคำภาษาอังกฤษ ให้สลับเป็นสำเนียงเจ้าของภาษา US
    if ENGLISH_WORD_PATTERN.search(text):
        if "Niwat" in current_voice or "Guy" in current_voice:
            return "en-US-GuyNeural"
        elif "Premwadee" in current_voice or "Ava" in current_voice:
            return "en-US-AvaNeural"
        elif current_voice.startswith("google-"):
            return "google-en"
        return "en-US-AvaNeural"

    return current_voice


class TTSMemoryCache:
    """
    ⚡ ระบบ In-Memory Pre-Cache สำหรับคำสตรีมเมอร์ยอดนิยมและข้อความสั้น
    - เก็บ Audio File ใน RAM Disk (/dev/shm) หรือ RAM Buffer
    - ตอบสนองเสียงทันที 0ms (Zero Latency) ไม่ต้องรอเน็ต Cloud TTS
    """
    def __init__(self, temp_dir: Path):
        self.temp_dir = temp_dir
        self._cache_bytes: Dict[tuple, bytes] = {}
        self._cache_files: Dict[tuple, Path] = {}
        self.hits: int = 0
        self.misses: int = 0
        self.custom_phrases: Set[str] = set()

    @staticmethod
    def normalize_key(text: str) -> str:
        # ลบช่องว่างซ้ำซ้อน ตัวพิมพ์เล็ก เพื่อให้การ match แม่นยำ
        return " ".join(text.strip().lower().split())

    def _get_key(self, text: str, voice: str, rate: str) -> tuple:
        return (self.normalize_key(text), voice, rate)

    def count(self) -> int:
        return len(self._cache_files)

    def get_phrases(self) -> List[str]:
        phrases = set()
        for k in self._cache_files.keys():
            phrases.add(k[0])
        return sorted(list(phrases))

    def get_cached_file(self, text: str, voice: str, rate: str) -> Optional[Path]:
        key = self._get_key(text, voice, rate)
        file_path = self._cache_files.get(key)
        if file_path and file_path.exists():
            self.hits += 1
            return file_path

        # กรณีมี bytes ในหน่วยความจำแต่ไฟล์ยังไม่ได้เขียนลง RAM disk
        if key in self._cache_bytes:
            self.hits += 1
            safe_name = f"cache_{abs(hash(key)) % 100000000:08d}.mp3"
            path = self.temp_dir / safe_name
            try:
                path.write_bytes(self._cache_bytes[key])
                self._cache_files[key] = path
                return path
            except Exception:
                pass
        self.misses += 1
        return None

    def put_cache(self, text: str, voice: str, rate: str, audio_bytes: bytes) -> Optional[Path]:
        key = self._get_key(text, voice, rate)
        # ป้องกัน RAM ล้น: จำกัดหน่วยความจำแคชไว้ 300 คำ
        if len(self._cache_bytes) > 300:
            first_key = next(iter(self._cache_bytes))
            del self._cache_bytes[first_key]
            old_file = self._cache_files.pop(first_key, None)
            if old_file and old_file.exists():
                try:
                    old_file.unlink()
                except Exception:
                    pass

        self._cache_bytes[key] = audio_bytes
        safe_name = f"cache_{abs(hash(key)) % 100000000:08d}.mp3"
        path = self.temp_dir / safe_name
        try:
            path.write_bytes(audio_bytes)
            self._cache_files[key] = path
            return path
        except Exception:
            return None

    async def warm_phrase(self, phrase: str, voice: str, rate: str):
        key = self._get_key(phrase, voice, rate)
        if key in self._cache_files and self._cache_files[key].exists():
            return

        safe_name = f"cache_{abs(hash(key)) % 100000000:08d}.mp3"
        dest_path = self.temp_dir / safe_name
        try:
            if voice.startswith("google-"):
                lang = voice.split("-")[1]
                def _gen():
                    tts = gTTS(text=phrase, lang=lang)
                    tts.save(str(dest_path))
                await asyncio.to_thread(_gen)
            else:
                communicate = edge_tts.Communicate(text=phrase, voice=voice, rate=rate)
                await communicate.save(str(dest_path))

            data = dest_path.read_bytes()
            self._cache_bytes[key] = data
            self._cache_files[key] = dest_path
        except Exception as e:
            logger.warning(f"[Pre-Cache] ไม่สามารถสังเคราะห์คำว่า '{phrase}' ({voice}): {e}")


@dataclass
class TTSItem:
    text: str
    author_name: str
    guild_id: int
    source: str = "Discord"
    voice: Optional[str] = None
    rate: Optional[str] = None


class GuildTTSState:
    def __init__(self, guild_id: int, bot: discord.Client, manager: 'TTSManager'):
        self.guild_id = guild_id
        self.bot = bot
        self.manager = manager
        self.queue: asyncio.Queue[TTSItem] = asyncio.Queue()
        self.bound_channel_id: Optional[int] = None
        self.voice: str = config.DEFAULT_VOICE
        self.rate: str = config.DEFAULT_RATE
        self.read_name: bool = False
        self.worker_task: Optional[asyncio.Task] = None
        self.current_audio_file: Optional[Path] = None
        self.current_playing_text: Optional[str] = None
        self.recent_logs: List[Dict[str, str]] = []
        self.twitch_listener = None
        self.twitch_channels: Set[str] = set()
        self.twitch_announce_channel: bool = True
        self.twitch_read_name: bool = True
        self.strip_emotes: bool = True
        self.auto_language: bool = True
        self.user_cooldown_seconds: float = 3.0
        self.blacklist: Set[str] = set()
        self.user_last_seen: Dict[str, float] = {}

    @property
    def is_playing(self) -> bool:
        guild = self.bot.get_guild(self.guild_id)
        if guild and guild.voice_client:
            return bool(guild.voice_client.is_playing())
        return bool(self.current_playing_text)

    async def stop_twitch(self):
        if self.twitch_listener:
            try:
                await self.twitch_listener.stop()
            except Exception as e:
                logger.error(f"[Guild {self.guild_id}] เกิดข้อผิดพลาดในการหยุด Twitch: {e}")
            self.twitch_listener = None
        self.twitch_channels.clear()

    async def add_twitch_channel(self, channel: str):
        clean_ch = channel.lower().strip().lstrip("#")
        if not clean_ch:
            return
        self.twitch_channels.add(clean_ch)
        if self.twitch_listener:
            await self.twitch_listener.add_channel(clean_ch)

    async def remove_twitch_channel(self, channel: str):
        clean_ch = channel.lower().strip().lstrip("#")
        self.twitch_channels.discard(clean_ch)
        if self.twitch_listener:
            await self.twitch_listener.remove_channel(clean_ch)
        if len(self.twitch_channels) == 0:
            await self.stop_twitch()

    def start_worker(self):
        if self.worker_task is None or self.worker_task.done():
            self.worker_task = asyncio.create_task(self._worker_loop())

    def stop_worker(self):
        if self.worker_task and not self.worker_task.done():
            self.worker_task.cancel()
            self.worker_task = None

    def clear_queue(self):
        while not self.queue.empty():
            try:
                self.queue.get_nowait()
                self.queue.task_done()
            except (asyncio.QueueEmpty, ValueError):
                break

    async def _worker_loop(self):
        while True:
            try:
                item = await self.queue.get()
            except asyncio.CancelledError:
                break

            guild = self.bot.get_guild(self.guild_id)
            if not guild:
                self.queue.task_done()
                continue

            voice_client: Optional[discord.VoiceClient] = guild.voice_client
            if not voice_client or not voice_client.is_connected():
                # บอทไม่ได้อยู่ในห้องเสียง ให้ข้ามไป
                self.queue.task_done()
                continue

            # Anti-flood: หากคิวสะสมเกิน 15 ข้อความ ให้ตัดข้อความเก่าออกเพื่อไล่ให้ทันแชทสด
            if self.queue.qsize() > 15:
                dropped = 0
                while self.queue.qsize() > 8:
                    try:
                        self.queue.get_nowait()
                        self.queue.task_done()
                        dropped += 1
                    except Exception:
                        break
                if dropped:
                    logger.warning(f"[Guild {self.guild_id}] ข้ามข้อความแชทเก่า {dropped} ข้อความ เพื่อเร่งให้ทันสตรีมสด")

            # ประกอบข้อความที่จะอ่าน
            spoken_text = item.text
            if self.read_name and item.author_name:
                spoken_text = f"{item.author_name} พูดว่า {spoken_text}"

            # ปรับสปีดอัตโนมัติเมื่อมีคิวรออ่านเยอะ (Dynamic Speed Boost)
            q_size = self.queue.qsize()
            effective_rate = item.rate or self.rate
            if q_size >= 8:
                effective_rate = "+40%"
            elif q_size >= 4:
                effective_rate = "+25%"

            # ตรวจสอบภาษาเพื่อเลือกเสียงสังเคราะห์ที่เหมาะสม (Auto Language Switch)
            selected_voice = get_voice_for_text(
                spoken_text,
                current_voice=item.voice or self.voice,
                auto_language=self.auto_language
            )

            audio_path: Optional[Path] = None
            is_from_cache = False

            try:
                # ⚡ เสาหลักที่ 3: เช็ค In-Memory Pre-Cache ใน RAM ก่อน (0 ms Audio Delay)
                cached_file = self.manager.cache.get_cached_file(spoken_text, selected_voice, effective_rate)
                if cached_file and cached_file.exists():
                    audio_path = cached_file
                    is_from_cache = True
                    logger.info(f"[Guild {self.guild_id}] ⚡ Pre-Cache Hit (0ms): '{spoken_text}'")
                else:
                    # สังเคราะห์เสียงใหม่ (เก็บใน RAM Disk /dev/shm)
                    audio_id = uuid.uuid4().hex[:8]
                    audio_path = config.TEMP_AUDIO_DIR / f"tts_{self.guild_id}_{audio_id}.mp3"
                    self.current_audio_file = audio_path

                    if selected_voice.startswith("google-"):
                        lang = selected_voice.split("-")[1]
                        def generate_gtts():
                            tts = gTTS(text=spoken_text, lang=lang)
                            tts.save(str(audio_path))
                        await asyncio.to_thread(generate_gtts)
                    else:
                        # สังเคราะห์เสียงด้วย Microsoft Edge TTS
                        communicate = edge_tts.Communicate(
                            text=spoken_text,
                            voice=selected_voice,
                            rate=effective_rate
                        )
                        await communicate.save(str(audio_path))

                    # บันทึกลง Memory Cache อัตโนมัติหากเป็นคำสั้น (<= 50 ตัวอักษร) เพื่อให้การอ่านซ้ำรอบหน้าตอบสนอง 0ms ทันที
                    if len(spoken_text) <= 50 and audio_path.exists():
                        try:
                            data = audio_path.read_bytes()
                            self.manager.cache.put_cache(spoken_text, selected_voice, effective_rate, data)
                        except Exception:
                            pass

                if not voice_client or not voice_client.is_connected():
                    continue

                # รอให้เสียงเดิมหยุดเล่นก่อน (ถ้ามี)
                while voice_client.is_playing() or voice_client.is_paused():
                    await asyncio.sleep(0.05)

                # บันทึกประวัติล่าสุดสำหรับ Dashboard
                self.current_playing_text = spoken_text
                log_source = item.source
                if is_from_cache:
                    log_source += " ⚡ [0ms Cache]"
                self.recent_logs.append({
                    "time": time.strftime("%H:%M:%S"),
                    "author": item.author_name or ("Web" if item.source == "Web" else "Chat"),
                    "text": spoken_text,
                    "source": log_source
                })
                if len(self.recent_logs) > 30:
                    self.recent_logs.pop(0)

                # ⚡ เสาหลักที่ 4: เล่นเสียงผ่าน Discord Voice ด้วย FFmpeg Low-Latency Optimization
                audio_source = discord.FFmpegPCMAudio(
                    str(audio_path),
                    executable=config.FFMPEG_EXECUTABLE,
                    before_options=config.FFMPEG_BEFORE_OPTIONS,
                    options=config.FFMPEG_OPTIONS
                )

                voice_client.play(audio_source)

                # รอจนกว่าเสียงจะเล่นจบ (ลด check interval เหลือ 0.05s เพื่อความต่อเนื่องของเสียง)
                while voice_client.is_playing() or voice_client.is_paused():
                    await asyncio.sleep(0.05)

            except Exception as e:
                logger.error(f"[Guild {self.guild_id}] เกิดข้อผิดพลาดในการเล่น TTS: {e}")
            finally:
                self.current_playing_text = None
                # ลบไฟล์เสียงชั่วคราว (เฉพาะไฟล์ที่ไม่ใช่ In-Memory Cache)
                if not is_from_cache and audio_path and audio_path.exists():
                    try:
                        audio_path.unlink()
                    except Exception:
                        pass
                self.current_audio_file = None
                self.queue.task_done()


class TTSManager:
    def __init__(self, bot: discord.Client):
        self.bot = bot
        self.states: Dict[int, GuildTTSState] = {}
        self.cache = TTSMemoryCache(config.TEMP_AUDIO_DIR)
        self.is_warming: bool = False

    def get_state(self, guild_id: int) -> GuildTTSState:
        if guild_id not in self.states:
            self.states[guild_id] = GuildTTSState(guild_id, self.bot, self)
        return self.states[guild_id]

    async def warm_default_cache(self, voices: Optional[List[str]] = None, rate: str = config.DEFAULT_RATE):
        """วอร์มเสียงคำสตรีมยอดฮิตลงใน RAM ล่วงหน้า เพื่อให้ตอบสนอง 0ms ทันทีที่สตาร์ตบอท"""
        if self.is_warming:
            return
        self.is_warming = True
        voices = voices or [config.DEFAULT_VOICE]
        logger.info(f"⚡ [Pre-Cache] เริ่มวอร์มเสียงคำสตรีมยอดนิยม {len(config.DEFAULT_PRECACHE_PHRASES)} คำ เข้าสู่ RAM ({config.TEMP_AUDIO_DIR})...")
        for phrase in config.DEFAULT_PRECACHE_PHRASES:
            for v in voices:
                try:
                    await self.cache.warm_phrase(phrase, v, rate)
                    await asyncio.sleep(0.02)
                except Exception as e:
                    logger.debug(f"[Pre-Cache] วอร์ม '{phrase}' ไม่สำเร็จ: {e}")
        self.is_warming = False
        logger.info(f"⚡ [Pre-Cache Complete] วอร์มเสียงเข้า RAM เรียบร้อยแล้ว {self.cache.count()} รายการ พร้อมความเร็ว 0ms!")

    async def enqueue(self, guild_id: int, text: str, author_name: str = "", source: str = "Discord", voice: Optional[str] = None, rate: Optional[str] = None):
        state = self.get_state(guild_id)
        state.start_worker()
        await state.queue.put(TTSItem(
            text=text,
            author_name=author_name,
            guild_id=guild_id,
            source=source,
            voice=voice,
            rate=rate
        ))

    def skip(self, guild_id: int) -> bool:
        guild = self.bot.get_guild(guild_id)
        if guild and guild.voice_client and guild.voice_client.is_playing():
            guild.voice_client.stop()
            return True
        return False

    def clear(self, guild_id: int):
        state = self.get_state(guild_id)
        state.clear_queue()
        guild = self.bot.get_guild(guild_id)
        if guild and guild.voice_client and guild.voice_client.is_playing():
            guild.voice_client.stop()
